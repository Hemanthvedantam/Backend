package com.example.agriculture.controller;

public class FarmController {
}
package com.example.agriculture.repository;

public interface FarmRepository {
}
package com.example.agriculture.service;

public class FarmService {
}
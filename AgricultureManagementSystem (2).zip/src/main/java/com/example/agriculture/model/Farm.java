package com.example.agriculture.model;

public class Farm {
}